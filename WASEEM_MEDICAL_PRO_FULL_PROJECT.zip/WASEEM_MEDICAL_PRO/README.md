# WASEEM MEDICAL PRO — نظام وسيم الطبي

نسخة Android محلية بقاعدة SQLite حقيقية، RTL، إدارة المرضى والمواعيد والجلسات والباقات والفواتير والقبض والمصروفات والمخزون والتقارير والنسخ الاحتياطي وWhatsApp اليدوي.

## تسجيل الدخول الأول
- المستخدم: `admin`
- كلمة المرور: `123456`

## بناء APK
```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

GitHub Actions في `.github/workflows/android.yml` يبني APK تلقائيًا عند الدفع إلى `main` أو `master` أو يدويًا من Actions.

> Google Drive: يحتاج إعداد OAuth خاص بالمشروع في Google Cloud، لذلك لا توضع مفاتيح سرية داخل المصدر.
