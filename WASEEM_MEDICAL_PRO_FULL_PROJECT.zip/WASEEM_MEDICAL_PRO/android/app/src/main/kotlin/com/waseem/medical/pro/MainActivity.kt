package com.waseem.medical.pro
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
