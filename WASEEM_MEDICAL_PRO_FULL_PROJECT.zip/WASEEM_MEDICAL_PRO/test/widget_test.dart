import 'package:flutter_test/flutter_test.dart';
import 'package:waseem_medical_pro/main.dart';
void main(){testWidgets('app smoke test',(tester) async{await tester.pumpWidget(const Splash());expect(find.text('وسيم ميديكال'),findsOneWidget);});}
